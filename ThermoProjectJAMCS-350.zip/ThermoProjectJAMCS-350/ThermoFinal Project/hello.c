#include <stdio.h>


/**
 * hello.c
 */
int main(void)
{
	printf("Hello World!\n");
	
	return 0;
}
